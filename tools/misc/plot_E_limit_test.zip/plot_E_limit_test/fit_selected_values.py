"""
Function fitter for energy spectrum plot limits

Author: Gokhan Oztarhan
Created date: 20/09/2012
Last modified: 20/09/2022
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('plot_E_limit_data.csv')

df = df.sort_values('n', ignore_index=True)

x = df['n'].to_numpy()
y = df['multiplier'].to_numpy()

plt.scatter(x,y, c='b', label='data')

x_val = np.linspace(x[0], x[-1], 1000)
y_val = np.zeros(x_val.shape)
for i, xx in enumerate(x_val):
    if xx <= 78:
        y_val[i] = -0.44667521 * np.log(xx) + 2.38053782
    elif xx <= 762:
        y_val[i] = -0.11001269 * np.log(xx) + 0.90267936
    elif xx <= 3282:
        y_val[i] = -0.06401283 * np.log(xx) + 0.60973256
    elif xx <= 10806:
        y_val[i] = -0.02693211 * np.log(xx) + 0.31730567
    else:
        y_val[i] = 0.04

plt.plot(x_val, y_val, '--g', label='fit-log', alpha=0.5)

plt.legend()
plt.show()



"""
Function fitter for energy spectrum plot limits

Author: Gokhan Oztarhan
Created date: 20/09/2012
Last modified: 20/09/2022
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def plot(x, y):
    x_val = np.linspace(x[0], x[-1], 1000)

    exp = np.polyfit(x, np.log(y), 1, w=np.sqrt(y))
    val_exp = np.exp(exp[0] * x_val) * np.exp(exp[1])

    log = np.polyfit(np.log(x), y, 1, w=np.log(y))
    val_log = log[0] * np.log(x_val) + log[1]
    
    inv2 = np.polyfit(1 / x**2, y, 1)
    val_inv2= inv2[0] / x_val**2 + inv2[1]

    poly_2 = np.polyfit(x, y, 2)
    val_2 = np.polyval(poly_2, x_val)

    poly_3 = np.polyfit(x, y, 3)
    val_3 = np.polyval(poly_3, x_val)

    poly_4 = np.polyfit(x, y, 4)
    val_4 = np.polyval(poly_4, x_val)
    
    print('exp', exp)
    print('log', log)
    print('inv2', inv2)
    print('poly_2', poly_2)
    print('poly_3', poly_3)
    print('poly_4', poly_4)
    print()

    plt.scatter(x, y, c='b', label='data')
    plt.plot(x, y, c='b', label='data')
    plt.plot(x_val, val_exp, '--r', label='exp')
    plt.plot(x_val, val_log, '--c', label='log')
    plt.plot(x_val, val_inv2, '--m', label='inv-2')
    plt.plot(x_val, val_2, '--g', label='poly-2')
    plt.plot(x_val, val_3, '--y', label='poly-3')
    plt.plot(x_val, val_4, '--k', label='poly-4')

df = pd.read_csv('plot_E_limit_data.csv')

df = df.sort_values('n', ignore_index=True)

x = df['n'].to_numpy()
y = df['multiplier'].to_numpy()

# log best
mask = np.logical_and(x >= 0, x <= 78) 
xx = x[mask]
yy = y[mask]
plot(xx, yy)

# log best
mask = np.logical_and(x >= 78, x <= 762) 
xx = x[mask]
yy = y[mask]
plot(xx, yy)

# log best
mask = np.logical_and(x >= 762, x <= 3282) 
xx = x[mask]
yy = y[mask]
plot(xx, yy)

# log best
mask = np.logical_and(x >= 3282, x <= 10806) 
xx = x[mask]
yy = y[mask]
plot(xx, yy)


plt.legend()
plt.show()


